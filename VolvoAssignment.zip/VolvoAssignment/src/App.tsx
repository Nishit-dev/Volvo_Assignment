import React from 'react';
import logo from './logo.svg';
import './App.css';

import VehicleComponent from './VehicleComponent/Vehiclecomponent'

function App() {
  return (
    <div className="App">
     <VehicleComponent/>
    </div>
  );
}

export default App;
