import React from "react";
import { SelectInput } from "vcc-ui";

export interface Props { }

export interface State {
    carsList: Array<any>;
    selected: string;
    filteredCarsList: Array<any>;
    optionsForFilter: Array<any>;
}

class VehicleComponent extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props);
        this.state = {
            carsList: [],
            selected: "",
            filteredCarsList: [],
            optionsForFilter: []
        };
    }
    componentDidMount() {
        let newCarsList: Array<any> = [];
        fetch("api/cars.json")
            .then((data) => data.json())
            .then((listOFcars) => {
                if (listOFcars?.length > 0) {
                    newCarsList = listOFcars;
                    this.setState({ carsList: newCarsList }, () => {
                        let options: Array<any> = [];
                        newCarsList.forEach(car => {
                            if (options.indexOf(car.bodyType) === -1) {
                                options.push(car.bodyType);
                            }
                        })
                        console.log(options)
                        this.setState({ optionsForFilter: options })
                    });
                }
            });
    }
    handleChange = (event) => {
        if (event.target.value) {
            const value = event.target.value
            this.setState({ selected: value });
            let filteredlist = this.state.carsList.filter(car => car.bodyType === value)
            this.setState({ filteredCarsList: filteredlist })
        }
    };

    render() {
        return (
            <React.Fragment>
                <br></br>
                <SelectInput value={this.state.selected} onChange={this.handleChange} label={'Please select a car from the list to filter.'}>
                    {this.state.carsList.length > 0 &&
                        this.state.optionsForFilter.map((option) => (
                            <option value={option}>{option}</option>
                        ))}
                </SelectInput>
                {this.state.selected === "" ? (
                    this.state.carsList.map((car) => (
                        <div style={{ "display": "inline-block", "width": "25%", "float": "left" }}>
                            <h4>{car.bodyType}</h4><br></br>
                            <div style={{ "display": "inline-flex" }}>
                                <h2>{car.modelName}</h2>
                                <h3>{car.modelType}</h3>
                            </div>
                            <img src={process.env.PUBLIC_URL + car.imageUrl} style={{ "height": "300px" }} />
                            <div>
                                <a href={'/learn/' + car.id}>Learn </a>
                                <br></br>
                                <a href={'/shop/' + car.id}>Shop </a>
                            </div>
                        </div>
                    ))
                ) : (
                        this.state.filteredCarsList.map((car) => (

                            <div style={{ "display": "inline-block", "width": "25%", "float": "left" }}>
                                <h4>{car.bodyType}</h4><br></br>
                                <div style={{ "display": "inline-flex" }}>
                                    <h2>{car.modelName}</h2>
                                    <h3>{car.modelType}</h3>
                                    <img src={process.env.PUBLIC_URL + car.imageUrl} style={{ "height": "300px" }} />
                                </div>
                                <div>
                                    <a href={'/learn/' + car.id}>Learn </a>
                                    <br></br>
                                    <a href={'/shop/' + car.id}>Shop </a>
                                </div>
                            </div>
                        ))
                    )}
            </React.Fragment>
        );
    }
}

export default VehicleComponent;
